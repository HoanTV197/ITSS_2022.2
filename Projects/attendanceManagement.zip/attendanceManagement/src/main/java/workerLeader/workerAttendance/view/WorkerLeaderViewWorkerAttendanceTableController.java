package main.java.workerLeader.workerAttendance.view;

import main.java.worker.attendance.WorkerAttendanceByMonth;
import main.java.worker.attendance.view.WorkerViewWorkerAttendanceTableController;

public class WorkerLeaderViewWorkerAttendanceTableController extends WorkerViewWorkerAttendanceTableController{

	public WorkerLeaderViewWorkerAttendanceTableController(String workerId, WorkerAttendanceByMonth workerAttendanceByMonth) {
		super(workerId, workerAttendanceByMonth);
	}
}

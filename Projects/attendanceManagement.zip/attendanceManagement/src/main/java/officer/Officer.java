package main.java.officer;

import main.java.employee.Employee;

public class Officer extends Employee{

	public Officer(String name, String employeeId, String gender, String dateOfBirth, String unitId) {
		super(name, employeeId, gender, dateOfBirth, unitId);
		
	}

}

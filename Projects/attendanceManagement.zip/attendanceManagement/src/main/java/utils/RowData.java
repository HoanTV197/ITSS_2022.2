package main.java.utils;

import java.util.List;

public class RowData {
	 
	 private String column0;
	 private String column1;
	 private String column2;
	 private String column3;
	 private String column4;
	 private String column5;
	 private String column6;
	 private String column7;
	 private String column8;
	 private String column9;
	 private String column10;
	 private String column11;
	 private String column12;
	 private String column13;
	 private String column14;
	 private String column15;
	 private String column16;
	 private String column17;
	 private String column18;
	 private String column19;
	 private String column20;
	 private String column21;
	 private String column22;
	 private String column23;
	 private String column24;
	 private String column25;
	 private String column26;
	 private String column27;
	 private String column28;
	 private String column29;
	 private String column30;
	 private String column31;
	 
	public RowData(List<String> listString) {
		super();
		this.column0 = listString.get(0);
		this.column1 = listString.get(1);
		this.column2 = listString.get(2);
		this.column3 = listString.get(3);
		this.column4 = listString.get(4);
		this.column5 = listString.get(5);
		this.column6 = listString.get(6);
		this.column7 = listString.get(7);
		this.column8 = listString.get(8);
		this.column9 = listString.get(9);
		this.column10 = listString.get(10);
		this.column11 = listString.get(11);
		this.column12 = listString.get(12);
		this.column13 = listString.get(13);
		this.column14 = listString.get(14);
		this.column15 = listString.get(15);
		this.column16 = listString.get(16);
		this.column17 = listString.get(17);
		this.column18 = listString.get(18);
		this.column19 = listString.get(19);
		this.column20 = listString.get(20);
		this.column21 = listString.get(21);
		this.column22 = listString.get(22);
		this.column23 = listString.get(23);
		this.column24 = listString.get(24);
		this.column25 = listString.get(25);
		this.column26 = listString.get(26);
		this.column27 = listString.get(27);
		this.column28 = listString.get(28);
		this.column29 = listString.get(29);
		this.column30 = listString.get(30);
		this.column31 = listString.get(31);
	}
	
	public String getColumn0() {
		return column0;
	}

	public void setColumn0(String column0) {
		this.column0 = column0;
	}

	public String getColumn1() {
		return column1;
	}
	public String getColumn2() {
		return column2;
	}
	public String getColumn3() {
		return column3;
	}
	public String getColumn4() {
		return column4;
	}
	public String getColumn5() {
		return column5;
	}
	public String getColumn6() {
		return column6;
	}
	public String getColumn7() {
		return column7;
	}
	public String getColumn8() {
		return column8;
	}
	public String getColumn9() {
		return column9;
	}
	public String getColumn10() {
		return column10;
	}
	public String getColumn11() {
		return column11;
	}
	public String getColumn12() {
		return column12;
	}
	public String getColumn13() {
		return column13;
	}
	public String getColumn14() {
		return column14;
	}
	public String getColumn15() {
		return column15;
	}
	public String getColumn16() {
		return column16;
	}
	public String getColumn17() {
		return column17;
	}
	public String getColumn18() {
		return column18;
	}
	public String getColumn19() {
		return column19;
	}
	public String getColumn20() {
		return column20;
	}
	public String getColumn21() {
		return column21;
	}
	public String getColumn22() {
		return column22;
	}
	public String getColumn23() {
		return column23;
	}
	public String getColumn24() {
		return column24;
	}
	public String getColumn25() {
		return column25;
	}
	public String getColumn26() {
		return column26;
	}
	public String getColumn27() {
		return column27;
	}
	public String getColumn28() {
		return column28;
	}
	public String getColumn29() {
		return column29;
	}
	public String getColumn30() {
		return column30;
	}
	public String getColumn31() {
		return column31;
	}			 
}

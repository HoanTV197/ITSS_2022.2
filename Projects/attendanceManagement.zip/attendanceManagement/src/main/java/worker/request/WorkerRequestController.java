package main.java.worker.request;

import main.java.officer.request.OfficerRequestController;

public class WorkerRequestController extends OfficerRequestController{

	public WorkerRequestController(String workerId) {
		super(workerId);
	}

}

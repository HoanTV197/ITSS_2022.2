package main.java.officerLeader.officerAttendance.view;

import main.java.hrAdmin.attendance.view.AdminViewEmployeeAttendanceController;

public class OfficerLeaderViewOfficerAttendanceController extends AdminViewEmployeeAttendanceController{

	
}
